package DataStructure;

import java.util.HashMap;

public class Node {
	
	public int Index;
	HashMap<Integer, Double> connectedNodes = new HashMap<Integer, Double>();
	
}
